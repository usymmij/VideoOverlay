#ifndef REVERSE_H
#define REVERSE_H

#include <avr/pgmspace.h>

extern const uint8_t reverseTable[];

#endif