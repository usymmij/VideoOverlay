#ifndef EDGE_TEMPLATES_H
#define EDGE_TEMPLATES_H

#include <avr/pgmspace.h>

extern unsigned char edges[16][3];

#endif



