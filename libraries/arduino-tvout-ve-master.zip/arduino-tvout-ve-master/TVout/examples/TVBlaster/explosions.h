# include <avr/pgmspace.h>
# ifndef EXPLOSIONS_H
# define EXPLOSIONS_H

extern const unsigned char explosion_bitmaps[];
#endif
